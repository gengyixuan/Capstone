from src.writer import writer
import argparse
import pickle as pkl
import os
parser=argparse.ArgumentParser()
parser.add_argument('--subtract', type=float)
parser.add_argument('--classifier', type=str)
args=parser.parse_args()
inputs=dict()
inputs['append1']=pkl.load(open('append1_output/append1.pkl', 'rb'))
inputs['append2']=pkl.load(open('append2_output/append2.pkl', 'rb'))
hps=dict()
hps['subtract']=args.subtract
hps['classifier']=args.classifier
rst=writer(inputs, hps)
if not os.path.exists('writer_output'):
	os.mkdir('writer_output')
pkl.dump(rst, open('writer_output/writer.pkl', 'wb'))
