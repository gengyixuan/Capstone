from src.append2 import append2
import argparse
import pickle as pkl
import os
parser=argparse.ArgumentParser()
parser.add_argument('--num', type=str)
args=parser.parse_args()
inputs=dict()
inputs['reader']=pkl.load(open('reader_output/reader.pkl', 'rb'))
hps=dict()
hps['num']=args.num
rst=append2(inputs, hps)
if not os.path.exists('append2_output'):
	os.mkdir('append2_output')
pkl.dump(rst, open('append2_output/append2.pkl', 'wb'))
