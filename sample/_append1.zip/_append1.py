from src.append1 import append1
import argparse
import pickle as pkl
import os
parser=argparse.ArgumentParser()
parser.add_argument('--num', type=str)
args=parser.parse_args()
inputs=dict()
inputs['reader']=pkl.load(open('reader_output/reader.pkl', 'rb'))
hps=dict()
hps['num']=args.num
rst=append1(inputs, hps)
if not os.path.exists('append1_output'):
	os.mkdir('append1_output')
pkl.dump(rst, open('append1_output/append1.pkl', 'wb'))
